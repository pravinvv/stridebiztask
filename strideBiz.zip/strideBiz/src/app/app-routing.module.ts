import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NavbarComponent } from './navbar/navbar.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [ 
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component:HomeComponent },
  { path: 'register', component:RegisterComponent },
  {path: 'login',component:LoginComponent},
  { path: 'navbar', component:NavbarComponent,
children:[
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, 
 { path: 'dashboard', component:DashboardComponent },
 { path: 'user-details', component:UserComponent }]}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
