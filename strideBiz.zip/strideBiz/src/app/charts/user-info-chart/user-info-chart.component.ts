import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType } from 'chart.js';
import { Label, SingleDataSet } from 'ng2-charts';

@Component({
  selector: 'app-user-info-chart',
  templateUrl: './user-info-chart.component.html',
  styleUrls: ['./user-info-chart.component.scss']
})
export class UserInfoChartComponent implements OnInit {

  public pieChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieChartLabels: Label[] = ['Total Users', 'Active User', 'Deactivated User'];
  public pieChartData: SingleDataSet = [900, 750, 150];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [];

  constructor() { }

  ngOnInit() {
  }

}
