import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserInfoChartComponent } from './user-info-chart.component';

describe('UserInfoChartComponent', () => {
  let component: UserInfoChartComponent;
  let fixture: ComponentFixture<UserInfoChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserInfoChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserInfoChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
