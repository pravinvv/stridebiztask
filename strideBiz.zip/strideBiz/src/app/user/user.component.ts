import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  rform: FormGroup;

  message;

  constructor(private fb: FormBuilder, private reg: UserService,private router: Router,) {}

  ngOnInit() {
    this.rform = this.fb.group({
      name: [
        "",
        Validators.compose([
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(20)
        ])
      ],
      email: ["", Validators.compose([Validators.required, Validators.email])],
      mobile: [
        "",
        Validators.compose([Validators.required, Validators.minLength(10)])
      ],
     subject: ["", Validators.compose([Validators.required])],
     
    });
  }

  save() {
    console.log(this.rform);
    this.reg.register(this.rform.value);
    alert("Saved Succesfully");

  }

  get f() {
    return this.rform.controls;
  }
}