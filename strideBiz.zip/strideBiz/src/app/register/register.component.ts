import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  rform: FormGroup;

  message;

  constructor(private fb: FormBuilder, private reg: UserService,private router: Router,) {}

  ngOnInit() {
    this.rform = this.fb.group({
      name: [
        "",
        Validators.compose([
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(20)
        ])
      ],
      email: ["", Validators.compose([Validators.required, Validators.email])],
      mobile: [
        "",
        Validators.compose([Validators.required, Validators.minLength(10)])
      ],
      password: ["", Validators.compose([Validators.required])],
      confirmpassword: ["", Validators.compose([Validators.required])]
    });
  }

  register() {
    console.log(this.rform);
    this.reg.register(this.rform.value);
    alert("Registered Succesfull");
    this.router.navigate(["/login"]);
  }

  get f() {
    return this.rform.controls;
  }
}